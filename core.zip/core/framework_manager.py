# core/framework_manager.py

import asyncio
from typing import List, Dict, Type, Optional

from core.base_test import BaseTest, TestResult
from core.browser_manager import BrowserManager
from core.cmp_handler import CMPHandler

from .framework.auth import AuthManager
from .framework.page_info import PageInfoDetector
from .framework.discovery import discover_tests, get_tests_by_category
from .framework.url_runner import URLRunner
from .framework.warmup import WarmupManager
from .framework.csv_writer import CSVWriter


class TestFramework:
    def __init__(self, config: Dict):
        self.config = config

        # Test registry
        self.tests: Dict[str, Type[BaseTest]] = {}
        self.test_categories: Dict[str, List[str]] = {}

        # Core components
        self.browser_manager = BrowserManager(config)
        self.cmp_handler = CMPHandler(config)

        # Framework helpers
        self.auth = AuthManager(config)
        self.page_info = PageInfoDetector(config)
        self.url_runner = URLRunner(config, self.auth, self.page_info, self.cmp_handler)
        self.warmup = WarmupManager(config, self.browser_manager, self.cmp_handler, self.auth)
        self.csv_writer = CSVWriter(config)

    # ------------- Test discovery -------------

    def discover_tests(self) -> None:
        """
        Populate:
          - self.tests (name -> class)
          - self.test_categories (category -> [names])
        """
        self.tests, self.test_categories = discover_tests()

    def get_tests_by_category(self, category: str) -> List[Type[BaseTest]]:
        """Get all tests in a specific category."""
        return get_tests_by_category(self.tests, self.test_categories, category)

    def create_test_instance(self, test_name: str) -> BaseTest:
        """Create instance of specific test (not heavily used now)."""
        if test_name in self.tests:
            return self.tests[test_name](self.config)
        raise ValueError(f"Test {test_name} not found")

    # ------------- URL selection -------------

    async def _get_selected_urls(self) -> List[str]:
        """
        Decide which URLs to test: driven entirely by config['urls'].
        """
        urls = list(self.config.get("urls", []))
        if not urls:
            print("⚠️ No URLs configured. Check config/site_urls.py and base_config.py")
        print(
            f"🧭 Using {len(urls)} URLs from site profile "
            f"({self.config.get('active_site')} | "
            f"{'UAT' if self.config.get('uat_mode') else 'LIVE'})"
        )
        return urls

    # ------------- Main runner -------------

    async def run_tests(
        self, test_names: Optional[List[str]] = None, category: str = None
    ) -> List[TestResult]:
        """Run specified tests, using either single-page mode or parallel mode."""
        results: List[TestResult] = []

        # Which tests to run? (we build the full pool of *classes*; site plan is applied per URL)
        if test_names:
            test_classes: List[Type[BaseTest]] = [
                self.tests[name]
                for name in test_names
                if name in self.tests
            ]
        elif category:
            test_classes = self.get_tests_by_category(category)
        else:
            test_classes = list(self.tests.values())

        if not test_classes:
            print("No tests found to run")
            return results

        # Start browser / context
        await self.browser_manager.start()
        print(f"🛫 Browser launched (mobile = {self.config.get('mobile', True)})")

        # Get URLs
        selected_urls = await self._get_selected_urls()
        total_urls = len(selected_urls)
        print(
            f"▶️  Starting crawl: {total_urls} URLs "
            f"(mobile={self.config.get('mobile', True)})"
        )

        if total_urls == 0:
            print("⚠️ No URLs found to test (config['urls'] is empty).")
            await self.browser_manager.close()
            return results

        # ---------- Warmup phase ----------
        parallel = self.config.get("parallel_tests", False)

        # Disable warmup for parallel mode (not meaningful for multi-page)
        if parallel:
            warm_page = None
        else:
            warm_page = await self.warmup.run_warmup(selected_urls)

        if not parallel:
            # Always reuse warmup page when available
            if warm_page:
                page = warm_page
            else:
                page = await self.browser_manager.new_page()

            for url_idx, url in enumerate(selected_urls, start=1):
                url_results = await self.url_runner.run_for_url(
                    page=page,
                    url=url,
                    test_classes=test_classes,
                    url_idx=url_idx,
                    total_urls=total_urls,
                    # If warmup ran, CMP already handled on first warmup URL
                    handle_cmp=(url_idx == 1 and warm_page is None),
                )
                results.extend(url_results)

            await page.close()

        else:
            # -------- PARALLEL MODE (bounded concurrency) --------
            # We don't reuse the warmup page here; close it if it exists.
            if warm_page is not None:
                await warm_page.close()

            concurrency = self.config.get("concurrency", 4)
            semaphore = asyncio.Semaphore(concurrency)

            async def run_for_url(url_idx: int, url: str) -> List[TestResult]:
                async with semaphore:
                    page = await self.browser_manager.new_page()
                    try:
                        return await self.url_runner.run_for_url(
                            page=page,
                            url=url,
                            test_classes=test_classes,
                            url_idx=url_idx,
                            total_urls=total_urls,
                            handle_cmp=(url_idx == 1 and False),  # CMP handled in warmup or not at all here
                        )
                    finally:
                        await page.close()

            tasks = [
                asyncio.create_task(run_for_url(idx, url))
                for idx, url in enumerate(selected_urls, start=1)
            ]
            url_results_lists = await asyncio.gather(*tasks)
            for url_results in url_results_lists:
                results.extend(url_results)

        # Close browser/context
        await self.browser_manager.close()

        # Write CSV output (still test × URL at this stage)
        await self.csv_writer.write_main(results)

        # Write additional page-type summary CSV
        await self.csv_writer.write_pagetype_summary(results)

        return results