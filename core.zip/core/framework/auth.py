# core/framework/auth.py

from typing import Dict, Any, List
from urllib.parse import urlparse, urlunparse


class AuthManager:
    """
    Handles:
      - Injecting basic auth into pre-prod URLs (uat/feat/dev or uat_mode)
      - Setting context cookies (device + UAT cookies)
    """

    def __init__(self, config: Dict[str, Any]):
        self.config = config

    def add_basic_auth_to_url(self, url: str) -> str:
        """
        If URL points to a UAT/DEV/FEAT environment, inject basic auth credentials
        like: https://demo:review@uat-web.independent.co.uk/...
        """
        if not url:
            return url

        url_l = url.lower()

        # Treat any host containing 'uat', 'feat', or 'dev' as pre-prod
        is_preprod_url = any(token in url_l for token in ("uat", "feat", "dev"))
        is_forced_uat = bool(self.config.get("uat_mode", False))

        # Only apply if clearly pre-prod OR uat_mode is explicitly enabled
        if not (is_preprod_url or is_forced_uat):
            return url

        username = "demo"
        password = "review"

        parsed = urlparse(url)

        # Avoid double-injecting
        if parsed.username or parsed.password:
            return url

        netloc = parsed.netloc
        if not netloc:
            return url

        parsed = parsed._replace(netloc=f"{username}:{password}@{netloc}")
        auth_url = urlunparse(parsed)
        print(f"🔐 Injected basic auth into URL for pre-prod (uat/feat/dev): {auth_url}")
        return auth_url

    async def set_context_cookies(self, page, url: str) -> None:
        """
        Set cookies BEFORE navigation.

        Always:
          - is_mobile_or_tablet

        For pre-prod (UAT / FEAT / DEV):
          - feature flag cookies from config['uat_cookies']
        """
        is_mobile = bool(self.config.get("mobile", True))
        uat_cookies: List[Dict[str, Any]] = self.config.get("uat_cookies", []) or []

        raw = url or self.config.get("site_url", "")
        parsed = urlparse(raw if raw else "https://www.independent.co.uk")
        host = parsed.hostname or "www.independent.co.uk"
        domain = host  # host-only cookie

        raw_l = (raw or "").lower()
        # Pre-prod if URL contains uat/feat/dev OR global uat_mode is set
        is_preprod_url = any(token in raw_l for token in ("uat", "feat", "dev"))
        uat_mode = bool(self.config.get("uat_mode", False) or is_preprod_url)

        cookies: List[Dict[str, Any]] = [
            {
                "name": "is_mobile_or_tablet",
                "value": "true" if is_mobile else "false",
                "domain": domain,
                "path": "/",
            }
        ]

        if uat_mode and uat_cookies:
            for base_cookie in uat_cookies:
                c = dict(base_cookie)           # shallow copy
                c.setdefault("domain", domain)  # apply current host if not set
                cookies.append(c)

        try:
            await page.context.add_cookies(cookies)
            print(
                f"🌍 Context cookies set (mobile={is_mobile}, preprod={uat_mode}): "
                f"{[c['name'] + '=' + c['value'] for c in cookies]}"
            )
        except Exception as e:
            print(f"⚠️ Failed to set context cookies: {e}")