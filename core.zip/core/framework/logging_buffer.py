# core/framework/logging_buffer.py

from typing import List


class URLLogger:
    """
    Small helper that buffers log lines for a single URL and prints them
    as one block to avoid interleaving when running in parallel.
    """

    def __init__(self, url_idx: int, total_urls: int, url: str):
        self.url_idx = url_idx
        self.total_urls = total_urls
        self.url = url
        self._lines: List[str] = []

    def log(self, *args) -> None:
        msg = " ".join(str(a) for a in args)
        self._lines.append(msg)

    def flush(self) -> None:
        block_lines: List[str] = [
            "",
            "=" * 80,
            f"📄 RESULT BLOCK FOR URL {self.url_idx}/{self.total_urls}",
            self.url,
            "=" * 80,
        ]
        block_lines.extend(self._lines)
        block_lines.append("=" * 80)
        block_lines.append("")

        print("\n".join(block_lines))