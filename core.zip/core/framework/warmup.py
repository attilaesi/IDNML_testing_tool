# core/framework/warmup.py

from typing import List, Optional

from core.readiness_waiter import ReadinessWaiter
from .auth import AuthManager


class WarmupManager:
    """
    Handles the optional warmup phase:

      - Navigates first N URLs
      - Injects basic auth & cookies
      - Handles CMP (first warmup only)
      - Waits for Prebid + GPT

    No tests are run, no results recorded.
    """

    def __init__(self, config, browser_manager, cmp_handler, auth: AuthManager):
        self.config = config
        self.browser_manager = browser_manager
        self.cmp_handler = cmp_handler
        self.auth = auth

    async def _warmup_url(
        self,
        page,
        url: str,
        warm_idx: int,
        total_warm: int,
        handle_cmp: bool,
    ) -> None:
        print(f"[WARMUP {warm_idx}/{total_warm}] {url}")

        auth_url = self.auth.add_basic_auth_to_url(url)
        await self.auth.set_context_cookies(page, auth_url)
        await page.goto(auth_url, wait_until="domcontentloaded")

        if handle_cmp:
            await self.cmp_handler.handle_consent(page)

        waiter = ReadinessWaiter(timeout=self.config.get("prebid_ready_timeout", 10))
        await waiter.wait_for_prebid_and_gpt(page)

        print(f"[WARMUP {warm_idx}/{total_warm}] done")

    async def run_warmup(self, urls: List[str]):
        """
        Run warmup for the first N URLs (based on config['warmup_pages']).

        Returns:
          - The warmup page (if created), so the caller may optionally reuse
            it in sequential mode, or None if no warmup was run.
        """
        warmup_pages = int(self.config.get("warmup_pages", 0) or 0)
        warmup_pages = max(0, min(warmup_pages, len(urls)))

        if warmup_pages <= 0:
            return None

        print(f"🔥 Warmup phase: loading first {warmup_pages} URL(s) without running tests")
        warm_page = await self.browser_manager.new_page()
        for w_idx, w_url in enumerate(urls[:warmup_pages], start=1):
            await self._warmup_url(
                page=warm_page,
                url=w_url,
                warm_idx=w_idx,
                total_warm=warmup_pages,
                handle_cmp=(w_idx == 1),
            )

        print("🔥 Warmup phase complete.\n")
        return warm_page