# core/framework/url_runner.py

import asyncio
from typing import Dict, Any, List, Type

from core.base_test import BaseTest, TestResult
from core.readiness_waiter import ReadinessWaiter
from config.site_test_plans import SITE_TEST_PLANS

from .auth import AuthManager
from .page_info import PageInfoDetector
from .logging_buffer import URLLogger


class URLRunner:
    """
    Handles the full lifecycle for a single URL:

      - Inject basic auth (if needed)
      - Set context cookies
      - Navigate
      - CMP handling
      - Wait for Prebid + GPT readiness
      - Wait for at least one GPT slotResponseReceived event
      - Detect pageType + Locale
      - Apply site test plan (exclude tests)
      - Run tests for this URL
      - Attach metadata
      - Log as a single block
    """

    def __init__(
        self,
        config: Dict[str, Any],
        auth: AuthManager,
        page_info: PageInfoDetector,
        cmp_handler,
    ):
        self.config = config
        self.auth = auth
        self.page_info = page_info
        self.cmp_handler = cmp_handler


    async def _wait_for_gpt_slot_response(self, page) -> None:
        timeout = float(self.config.get("gpt_slot_response_timeout", 5.0))
        interval = 0.25
        elapsed = 0.0

        js_attach = """
        () => {
          try {
            if (!window.googletag || !googletag.apiReady || !googletag.pubads) {
              return { attached: false, reason: "googletag not ready" };
            }
            const pubads = googletag.pubads();
            if (!pubads || !pubads.addEventListener) {
              return { attached: false, reason: "pubads.addEventListener missing" };
            }

            if (window.__idnmlSlotRespListenerAttached) {
              return { attached: true, reason: "already attached" };
            }

            window.__idnmlSlotRespListenerAttached = true;
            window.__idnmlSlotResponses = window.__idnmlSlotResponses || [];

            pubads.addEventListener("slotResponseReceived", (e) => {
              try {
                const slot = e.slot;
                const id = slot && slot.getAdUnitPath ? slot.getAdUnitPath() : "unknown";
                if (!window.__idnmlSlotResponses.includes(id)) {
                  window.__idnmlSlotResponses.push(id);
                }
              } catch (_) {}
            });

            return { attached: true };
          } catch (err) {
            return { attached: false, reason: String(err) };
          }
        }
        """

        js_check = """
        () => {
          try {
            const arr = window.__idnmlSlotResponses;
            if (!arr) return { count: 0, values: [] };
            return { count: arr.length, values: arr.slice() };
          } catch (_) {
            return { count: 0, values: [] };
          }
        }
        """

        await page.evaluate(js_attach)

        while elapsed < timeout:
            data = await page.evaluate(js_check)
            if data and data.get("count", 0) > 0:
                print(f"✅ GPT slotResponseReceived fired for {data['count']} slot(s)")
                return

            await asyncio.sleep(interval)
            elapsed += interval

        print("⚠️ No GPT slotResponseReceived event detected before timeout.")


    async def _wait_for_gpt_slot_response(self, page) -> None:
        """
        Wait for at least one googletag.pubads().slotResponseReceived event.

        - Sets up a one-time listener in the page.
        - Polls a small JS array until at least one entry is present or timeout expires.
        """
        timeout = float(self.config.get("gpt_slot_response_timeout", 5.0))
        interval = 0.25
        elapsed = 0.0

        js_attach = """
        () => {
          try {
            if (!window.googletag || !googletag.apiReady || !googletag.pubads) {
              return { attached: false, reason: "googletag not ready" };
            }
            const pubads = googletag.pubads();
            if (!pubads || !pubads.addEventListener) {
              return { attached: false, reason: "pubads.addEventListener missing" };
            }

            // Only attach once
            if (window.__idnmlSlotRespListenerAttached) {
              return { attached: true, reason: "already attached" };
            }
            window.__idnmlSlotRespListenerAttached = true;

            window.__idnmlSlotResponses = window.__idnmlSlotResponses || [];

            pubads.addEventListener("slotResponseReceived", (event) => {
              try {
                const slot = event.slot;
                const id = slot && slot.getAdUnitPath ? slot.getAdUnitPath() : "unknown";
                if (!window.__idnmlSlotResponses.includes(id)) {
                  window.__idnmlSlotResponses.push(id);
                }
              } catch (e) {
                // swallow
              }
            });

            return { attached: true, reason: "listener attached" };
          } catch (e) {
            return { attached: false, reason: String(e) };
          }
        }
        """

        js_check = """
        () => {
          try {
            if (!Array.isArray(window.__idnmlSlotResponses)) {
              return { count: 0, values: [] };
            }
            return {
              count: window.__idnmlSlotResponses.length,
              values: window.__idnmlSlotResponses.slice()
            };
          } catch (e) {
            return { count: 0, values: [] };
          }
        }
        """

        # Attach listener (best-effort)
        attach_result = await page.evaluate(js_attach)
        if isinstance(attach_result, dict):
            if not attach_result.get("attached"):
                # Don't blow up on failure; just log and exit.
                reason = attach_result.get("reason", "")
                print(f"⚠️ Could not attach slotResponseReceived listener: {reason}")
                return
        else:
            # Unexpected shape, just continue
            pass

        # Poll for at least one slotResponseReceived
        while elapsed < timeout:
            data = await page.evaluate(js_check)
            try:
                count = int(data.get("count", 0))
            except Exception:
                count = 0

            if count > 0:
                print(f"✅ GPT slotResponseReceived seen for {count} slot(s)")
                return

            await asyncio.sleep(interval)
            elapsed += interval

        print("⚠️ No GPT slotResponseReceived seen before timeout; continuing anyway.")

    async def run_for_url(
        self,
        page,
        url: str,
        test_classes: List[Type[BaseTest]],
        url_idx: int,
        total_urls: int,
        handle_cmp: bool,
    ) -> List[TestResult]:
        """
        Navigate to URL, prepare environment, run all tests, return results.

        All logging for this URL is buffered and printed as a single
        grouped block (helps readability when running in parallel).
        """
        logger = URLLogger(url_idx, total_urls, url)
        logger.log(f"[{url_idx}/{total_urls}] Processing {url}")

        # Inject credentials for UAT/DEV/feature branches if needed
        auth_url = self.auth.add_basic_auth_to_url(url)

        # Set device + UAT/feature cookies before navigation
        await self.auth.set_context_cookies(page, auth_url)

        # Navigate & wait for DOM
        await page.goto(auth_url, wait_until="domcontentloaded")

        # CMP only once per session / first URL (per mode, depending on warmup)
        if handle_cmp:
            await self.cmp_handler.handle_consent(page)

        # Wait until pbjs & GPT are fully ready
        waiter = ReadinessWaiter(timeout=self.config.get("prebid_ready_timeout", 10))
        await waiter.wait_for_prebid_and_gpt(page)
        await self._wait_for_gpt_slot_response(page)

        # Wait for at least one GPT slotResponseReceived (best-effort)
        await self._wait_for_gpt_slot_response(page)

        # Detect page type from GPT key-values (with small polling window)
        page_type_norm = await self.page_info.detect_page_type(page)
        logger.log(f"🧩 Detected page type: {page_type_norm}")

        # Detect locale from Locale cookie (UK / US)
        locale = await self.page_info.detect_locale(page)
        logger.log(f"🗺️  Detected locale: {locale}")

        # 🔸 Apply site test plan (inherit-all, then exclude by page type)
        site_id = str(self.config.get("active_site", "independent")).lower()
        site_plan = SITE_TEST_PLANS.get(site_id, {})

        def _class_name(cls: Type[BaseTest]) -> str:
            return getattr(cls, "name", cls.__name__)

        if site_plan and site_plan.get("exclude") is not None:
            excluded_site = set(site_plan.get("exclude", []))
            exclude_map = site_plan.get("exclude_by_page_type", {}) or {}
            excluded_pt = set(exclude_map.get(page_type_norm, []))

            # Final disallowed set for this URL
            disallowed = excluded_site | excluded_pt

            # Only instantiate / run tests that are allowed for this URL
            run_classes = [
                cls for cls in test_classes if _class_name(cls) not in disallowed
            ]
        else:
            # No site plan -> run everything discovered
            run_classes = list(test_classes)

        url_results: List[TestResult] = []

        # Run each test for this URL (fresh instance per class)
        for cls in run_classes:
            test_name = _class_name(cls)
            test = cls(self.config)

            # Expose locale on the test instance so tests can read self.locale
            try:
                setattr(test, "locale", locale)
            except Exception:
                pass

            try:
                result = await test.run(page, url)

                # Attach page_type and locale into metadata so tests/reporting can use it later
                try:
                    if hasattr(result, "metadata"):
                        if result.metadata is None:
                            result.metadata = {}
                        if isinstance(result.metadata, dict):
                            result.metadata.setdefault("page_type", page_type_norm)
                            result.metadata.setdefault("locale", locale)
                except Exception:
                    pass

                url_results.append(result)
                logger.log(f"  {test_name}: {result.state.value}")
            except Exception as e:
                logger.log(f"  {test_name}: ERROR - {str(e)}")

        left = total_urls - url_idx
        logger.log(f"[{url_idx}/{total_urls}] done, {left} left")

        # Flush buffered log as a single block so parallel runs don't interleave
        logger.flush()

        return url_results